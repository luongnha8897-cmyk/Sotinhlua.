HUONG DAN TAO APK BANG DIEN THOAI ANDROID

Du an co san workflow GitHub Actions de bien dich APK tren may chu dam may.

Luu y: ZIP nay la MA NGUON, khong phai APK da bien dich.

Cach lam:
1. Tren dien thoai, mo Chrome va dang nhap https://github.com
2. Tao repository moi, dat ten SoTinhLuaAndroid, chon Public hoac Private.
3. Giai nen ZIP nay bang ung dung Quan ly tep. Tai trang repository GitHub, vao Add file > Upload files va tai len toan bo noi dung thu muc giai nen (bao gom thu muc .github va android_apk_project). Neu trinh duyet dien thoai khong cho tai len ca thu muc, can dung mot cach upload repository ho tro thu muc, hoac dung GitHub Codespaces/Termux.
4. Sau khi cac file da len repository nhanh main, vao tab Actions.
5. Chon workflow Build Android APK va bam Run workflow (neu workflow chua tu chay).
6. Cho workflow chay xong mau xanh. Mo lan chay do, keo xuong Artifacts va tai SoTinhLua-debug-apk.zip.
7. Giai nen file artifact, lay app-debug.apk va mo de cai dat. Neu Android can phep, cho phep Chrome/Files cai ung dung khong ro nguon.

Neu khong thay tab Actions, kiem tra workflow nam dung o .github/workflows/build-apk.yml va da duoc commit len nhanh main.
