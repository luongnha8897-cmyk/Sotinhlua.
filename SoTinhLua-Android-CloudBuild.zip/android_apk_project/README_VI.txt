SO TINH LUA - DU AN ANDROID

Luu y: goi hien tai chua co Android SDK/Gradle va moi truong tao file khong ket noi duoc Internet, nen chua the xuat APK cai dat truc tiep tai day.

Cach tao APK:
1. Giai nen file SoTinhLua-AndroidStudio.zip tren may tinh.
2. Cai Android Studio (https://developer.android.com/studio).
3. Mo Android Studio > Open > chon thu muc SoTinhLua.
4. Cho Android Studio dong bo Gradle va cai Android SDK Platform 35 neu duoc hoi.
5. Chon Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug thuong nam tai app/build/outputs/apk/debug/app-debug.apk.
7. Chuyen APK sang dien thoai Android, mo file va cho phep cai ung dung tu nguon nay neu duoc hoi.

Ung dung: So tinh lua, chay ngoai tuyen, cac o nhap lieu va phieu luu duoc giu tren may.
